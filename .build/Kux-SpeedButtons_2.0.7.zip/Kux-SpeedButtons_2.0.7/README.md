# Kuxynator's Speed Buttons

Configurable buttons for different game speeds and Auto Speed Change when crafting or mining. 

## Info

The main reason to create this mod was the compatibility. The original TimeButtons was only available until Factorio 0.17

Speed Buttons 1.0.0 has no new features. Only some code has been rewriten to work with Factorio 1.0

Based on [TimeButtons](https://mods.factorio.com/mod/TimeButtons) by [darius456](https://mods.factorio.com/user/darius456)